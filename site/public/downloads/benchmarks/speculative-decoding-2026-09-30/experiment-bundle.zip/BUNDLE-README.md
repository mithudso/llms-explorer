# Speculative decoding experiment: public source overlay and evidence

Version: 1.0.0. Recorded: 2026-09-30. Public export of the Apple Silicon target and RTX 5080 draft experiment.

**Qualification failed.** Four of 30 corrected trial comparisons fail exact token parity. The existing Qwen2-beta-14B-Chat draft yields about 1.2–2.5 committed target IDs/sec against 21.13 for the plain native target. This is an experimental implementation with saved failures. No production research routing change or speedup is qualified.

## Read the evidence

- [Machine-readable comparison](comparison.json): strict mismatches, acceptance, full-precision rates, ordinary-output comparison and provenance.
- [Validation plan](docs/research/speculative-decoding-validation-plan-2026-09-30.md): gates, commands, fixtures, rate scopes and stop conditions.
- [Block parity diagnosis](docs/research/speculative-decoding-block-parity-2026-09-30.md): same-prefix controls and unresolved numerical/cache explanations.
- [Native verifier build and protocol](native/speculative-mlx/README.md): explicit model loading, library discovery and cache convention.
- [Final verification receipt](docs/verification/speculative-decoding-2026-09-30/verification-report.json): the historical implementation checks, not a new qualification run.
- [Export manifest](manifest.json): verify each extracted public file against its public_sha256.

The complete original experiment JSON records are included after sanitization. Malformed BOS-free prompt receipts are retained and labeled mechanical-only. Corrected strict failures remain failures. Selected-logit diagnostics retain exact prompts, token IDs, logits, prefix digests and verdicts. The ordinary API controls expose output bytes and actual eval_count, not sampled token IDs. All six normalized counts agree; four of six output-byte comparisons agree. Native terminal EOS is removed only for API byte/count comparisons.

## Use the source overlay

Extract this ZIP onto a separate copy of the public repository, preserving these relative paths. It contains only the speculative package, its six test files, the diagnostic helper, the native Go sidecar, the package metadata, research documents, experiment receipts and license. It deliberately does not contain the rest of the application or model weights. It can overlay a repository copy even when the experiment's original local commit has not been published. Keep this experiment separate from your production model settings.

From that repository copy, the harness works without third-party Python runtime dependencies:

```sh
PYTHONPATH=llmsx python3 -m llmsx.speculative --help
```

CPU tests require pytest; run the scoped tests in an environment that already has it:

```sh
PYTHONPATH=llmsx python3 -m pytest llmsx/tests/test_speculative*.py -q
```

The native verifier requires Apple Silicon, Go 1.26 or newer, CGO/clang, compatible Ollama MLX libraries, and the exact existing canonical model manifest. Follow its README for library discovery, `--probe` and explicit startup. No model weights or compiled binary are distributed. `doctor` reads existing endpoint metadata; it does not start services or generate. Live validation requires explicit `--execute`. Do not start a second NVIDIA NV owner. The recorded RTX setup is a same-Mac TinyGPU/tinygrad route, not a conventional CUDA server.

## Provenance and sanitization

The local recorded source snapshot is `239f4ed2c88c3c334e41978d9656de2bd3e1d07e`. This identifier describes where the original files were read. It is not a public commit URL, a claim of remote publication, or a requirement for obtaining the complete source overlay.

`manifest.json` separates original committed source bytes (`raw_source_sha256`) from extracted publication bytes (`public_sha256`). A transformed JSON or Markdown file has different hashes. The original `sources` and `receipts` hash fields inside records remain original-source provenance. Compare their public bytes with the manifest, not with those raw-source fields. Derived public files list their inputs separately. The manifest excludes itself from its hash list because a self-hash would be circular.

The export removes actual per-run/session identifiers, raw thinking/reasoning fields, credential-like fields, and private home/runtime paths. Numeric timing and thinking_bytes counts, synthetic prompts, exact generated IDs, logits and verdicts remain. Literal thought-channel prompt cues and empty channel delimiters are template syntax, not disclosed private reasoning. Source code still names protocol fields such as session_id because the reproducible implementation needs that schema; example IDs are synthetic.

No inference, indexing, installation or service change was performed to create this export. Original tests and hardware checks are historical receipts. A static export check does not certify real Metal or NVIDIA behavior.

## Initial investigation source boundary

The feasibility dossier predates backend implementation. Its unmeasured proposals are retained as dated research, not current speedup claims. The original private host qualification and manifest-audit files are outside this bundle. Their earlier links now point to this boundary note. Public model/configuration links in that dossier supply upstream context; they do not independently prove installation state or assistant activation. The later corrected hardware receipts and comparison take precedence for measured behavior. The actual projection/attention kernel responsible for the divergence remains unresolved.
